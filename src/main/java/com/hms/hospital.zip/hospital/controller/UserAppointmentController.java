package com.hms.hospital.controller;

import com.hms.hospital.entity.Appointment;
import com.hms.hospital.entity.Patient;
import com.hms.hospital.entity.Prescription;
import com.hms.hospital.entity.User;
import com.hms.hospital.entity.Doctor;
import com.hms.hospital.entity.Department;
import com.hms.hospital.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Controller
@RequestMapping("/user")
public class UserAppointmentController {

    @Autowired
    private AppointmentRepository appointmentRepository;
    
    @Autowired
    private PatientRepository patientRepository;
    
    @Autowired
    private DoctorRepository doctorRepository;
    
    @Autowired
    private DepartmentRepository departmentRepository;
    
    @Autowired
    private PrescriptionRepository prescriptionRepository;
    
    @Autowired
    private UserRepository userRepository;

    @GetMapping("/appointments")
    public String getUserAppointments(Model model, Authentication authentication) {
        if (authentication != null) {
            String username = authentication.getName();
            User user = userRepository.findByUsername(username).orElse(null);
            if (user != null) {
                List<Patient> patients = patientRepository.findByUser(user);
                List<Appointment> appointments = appointmentRepository.findByPatientIn(patients);
                model.addAttribute("appointments", appointments);
                model.addAttribute("patients", patients);
                model.addAttribute("doctors", doctorRepository.findAll());
                model.addAttribute("departments", departmentRepository.findAll());
            }
        }
        return "user/appointments";
    }

    @GetMapping("/appointments/add")
    public String showAddAppointmentForm(Model model, Authentication authentication) {
        if (authentication != null) {
            String username = authentication.getName();
            User user = userRepository.findByUsername(username).orElse(null);
            if (user != null) {
                model.addAttribute("patients", patientRepository.findByUser(user));
                model.addAttribute("doctors", doctorRepository.findAll());
                model.addAttribute("departments", departmentRepository.findAll());
            }
        }
        return "user/appointments_add";
    }

    @PostMapping("/appointments/add")
    public String addUserAppointment(@RequestParam Long patientId,
                                  @RequestParam Long doctorId,
                                  @RequestParam Long departmentId,
                                  @RequestParam String dateTime,
                                  @RequestParam String reason,
                                  Model model) {
        Patient patient = patientRepository.findById(patientId).orElse(null);
        Doctor doctor = doctorRepository.findById(doctorId).orElse(null);
        Department dept = departmentRepository.findById(departmentId).orElse(null);
        if (patient != null && doctor != null) {
            Appointment appt = new Appointment();
            appt.setPatient(patient);
            appt.setDoctor(doctor);
            appt.setDepartment(dept);
            appt.setAppointmentDate(LocalDateTime.parse(dateTime));
            appt.setReason(reason);
            appt.setStatus("SCHEDULED");
            appointmentRepository.save(appt);
        }
        return "redirect:/user/appointments";
    }

    @GetMapping("/records")
    public String getUserRecords(Model model, Authentication authentication) {
        if (authentication != null) {
            String username = authentication.getName();
            User user = userRepository.findByUsername(username).orElse(null);
            if (user != null) {
                List<Patient> patients = patientRepository.findByUser(user);
                model.addAttribute("patients", patients);
            }
        }
        return "user/records";
    }

    @GetMapping("/doctors")
    public String getUserDoctors(Model model, Authentication authentication) {
        if (authentication != null) {
            model.addAttribute("doctors", doctorRepository.findAll());
        }
        return "user/doctors";
    }

    @GetMapping("/prescriptions")
    public String getUserPrescriptions(Model model, Authentication authentication) {
        List<Prescription> prescriptions = new java.util.ArrayList<>();
        if (authentication != null) {
            String username = authentication.getName();
            User user = userRepository.findByUsername(username).orElse(null);
            if (user != null) {
                List<Patient> patients = patientRepository.findByUser(user);
                for (Patient patient : patients) {
                    prescriptions.addAll(prescriptionRepository.findByPatient(patient));
                }
            }
            model.addAttribute("prescriptions", prescriptions);
            model.addAttribute("doctors", doctorRepository.findAll());
            model.addAttribute("patients", patientRepository.findAll());
        }
        return "user/prescriptions";
    }

    @PostMapping("/prescriptions/add")
    public String addPrescription(@RequestParam String medicineName,
                                  @RequestParam String dosage,
                                  @RequestParam String frequency,
                                  @RequestParam String duration,
                                  @RequestParam Long patientId,
                                  @RequestParam Long doctorId,
                                  @RequestParam String notes,
                                  Model model) {
        try {
            Patient patient = patientRepository.findById(patientId).orElse(null);
            var doctor = doctorRepository.findById(doctorId).orElse(null);
            
            if (patient != null && doctor != null) {
                Prescription prescription = new Prescription();
                prescription.setPatient(patient);
                prescription.setDoctor(doctor);
                prescription.setMedicineName(medicineName);
                prescription.setDosage(dosage);
                prescription.setFrequency(frequency);
                prescription.setDuration(duration);
                prescription.setPrescribedDate(LocalDate.now());
                prescription.setNotes(notes);
                
                prescriptionRepository.save(prescription);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return "redirect:/user/prescriptions";
    }

    @GetMapping("/alerts")
    public String getUserAlerts(Model model) {
        return "user/alerts";
    }

    @GetMapping("/settings")
    public String getUserSettings(Model model) {
        return "user/settings";
    }
}

