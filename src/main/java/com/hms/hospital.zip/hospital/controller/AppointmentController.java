package com.hms.hospital.controller;

import com.hms.hospital.entity.Appointment;
import com.hms.hospital.entity.Department;
import com.hms.hospital.entity.Doctor;
import com.hms.hospital.entity.Patient;
import com.hms.hospital.repository.AppointmentRepository;
import com.hms.hospital.repository.DepartmentRepository;
import com.hms.hospital.repository.DoctorRepository;
import com.hms.hospital.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;
import java.util.List;

@Controller
@RequestMapping("/admin/appointments")
public class AppointmentController {

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @GetMapping
    public String getAppointments(Model model) {
        List<Appointment> appts = appointmentRepository.findAll();
        model.addAttribute("appointments", appts);
        model.addAttribute("patients", patientRepository.findAll());
        model.addAttribute("doctors", doctorRepository.findAll());
        model.addAttribute("departments", departmentRepository.findAll());
        // debug logging
        System.out.println("[DEBUG] Model attributes for /admin/appointments:");
        model.asMap().forEach((k,v) -> {
            System.out.println("  key='" + k + "' class=" + (v != null ? v.getClass().getName() : "null"));
            if ("appointments".equals(k) && v instanceof java.util.List<?> list) {
                for (Object item : list) {
                    System.out.println("    element class=" + (item != null ? item.getClass().getName() : "null") + " -> " + item);
                }
            }
        });
        return "appointments/list";
    }

    @PostMapping
    public String addAppointment(@RequestParam Long patientId,
                                 @RequestParam Long doctorId,
                                 @RequestParam Long departmentId,
                                 @RequestParam String dateTime,
                                 @RequestParam String reason,
                                 @RequestParam String status) {
        Patient patient = patientRepository.findById(patientId).orElse(null);
        Doctor doctor = doctorRepository.findById(doctorId).orElse(null);
        Department dept = departmentRepository.findById(departmentId).orElse(null);
        Appointment appt = new Appointment();
        appt.setPatient(patient);
        appt.setDoctor(doctor);
        appt.setDepartment(dept);
        appt.setAppointmentDate(LocalDateTime.parse(dateTime));
        appt.setReason(reason);
        appt.setStatus(status);
        appointmentRepository.save(appt);
        return "redirect:/admin/appointments";
    }
}
