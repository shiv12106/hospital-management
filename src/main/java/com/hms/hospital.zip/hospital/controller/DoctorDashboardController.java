package com.hms.hospital.controller;

import com.hms.hospital.entity.Appointment;
import com.hms.hospital.entity.Doctor;
import com.hms.hospital.entity.Patient;
import com.hms.hospital.entity.Report;
import com.hms.hospital.repository.AppointmentRepository;
import com.hms.hospital.repository.DoctorRepository;
import com.hms.hospital.repository.PatientRepository;
import com.hms.hospital.repository.ReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/doctor")
public class DoctorDashboardController {
    
    @Autowired
    private DoctorRepository doctorRepository;
    
    @Autowired
    private AppointmentRepository appointmentRepository;
    
    @Autowired
    private PatientRepository patientRepository;
    
    @Autowired
    private ReportRepository reportRepository;
    
    @GetMapping("/dashboard")
    public String getDoctorDashboard(Model model) {
        // Get current doctor's username
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();
        
        // For now, get first doctor (in production, link User to Doctor)
        List<Doctor> allDoctors = doctorRepository.findAll();
        Doctor doctor = allDoctors.isEmpty() ? null : allDoctors.get(0);
        
        if (doctor != null) {
            model.addAttribute("doctor", doctor);
            
            // Get doctor's appointments
            List<Appointment> appointments = appointmentRepository.findAll();
            List<Appointment> doctorAppointments = appointments.stream()
                    .filter(a -> a.getDoctor().getId().equals(doctor.getId()))
                    .toList();
            model.addAttribute("appointments", doctorAppointments);
            
            // Get all patients (doctor can see all patients in their department)
            List<Patient> patients = patientRepository.findAll();
            model.addAttribute("patients", patients);
            
            // Get statistics
            model.addAttribute("totalPatients", patients.size());
            model.addAttribute("totalAppointments", doctorAppointments.size());
            model.addAttribute("totalReports", reportRepository.count());
        }
        
        return "doctor/dashboard";
    }
    
    @GetMapping("/patients")
    public String getPatients(Model model) {
        List<Patient> patients = patientRepository.findAll();
        model.addAttribute("patients", patients);
        return "doctor/patients";
    }
    
    @GetMapping("/patients/{id}")
    public String getPatientDetails(@PathVariable Long id, Model model) {
        Patient patient = patientRepository.findById(id).orElse(null);
        if (patient != null) {
            model.addAttribute("patient", patient);
            
            // Get patient's appointments
            List<Appointment> appointments = appointmentRepository.findAll();
            List<Appointment> patientAppointments = appointments.stream()
                    .filter(a -> a.getPatient().getId().equals(patient.getId()))
                    .toList();
            model.addAttribute("appointments", patientAppointments);
            
            // Get patient's reports
            List<Report> reports = reportRepository.findAll();
            model.addAttribute("reports", reports);
        }
        return "doctor/patient-details";
    }
    
    @GetMapping("/appointments")
    public String getAppointments(Model model) {
        // Get current doctor
        List<Doctor> allDoctors = doctorRepository.findAll();
        Doctor doctor = allDoctors.isEmpty() ? null : allDoctors.get(0);
        
        if (doctor != null) {
            List<Appointment> appointments = appointmentRepository.findAll();
            List<Appointment> doctorAppointments = appointments.stream()
                    .filter(a -> a.getDoctor().getId().equals(doctor.getId()))
                    .toList();
            model.addAttribute("appointments", doctorAppointments);
        }
        return "doctor/appointments";
    }
    
    @GetMapping("/reports")
    public String getReports(Model model) {
        List<Report> reports = reportRepository.findAll();
        model.addAttribute("reports", reports);
        return "doctor/reports";
    }
}
