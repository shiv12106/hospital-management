package com.hms.hospital.controller;

import com.hms.hospital.entity.Patient;
import com.hms.hospital.entity.User;
import com.hms.hospital.repository.PatientRepository;
import com.hms.hospital.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/admin/patients")
public class PatientController {

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private UserRepository userRepository;

    @GetMapping
    public String getPatients(Model model) {
        List<Patient> patients = patientRepository.findAll();
        model.addAttribute("patients", patients);
        model.addAttribute("users", userRepository.findAll());
        return "patients/list";
    }

    @PostMapping
    public String addPatient(@RequestParam String name,
                             @RequestParam String email,
                             @RequestParam String phone,
                             @RequestParam String dateOfBirth,
                             @RequestParam String address,
                             @RequestParam String bloodGroup,
                             @RequestParam(required = false) String medicalHistory,
                             @RequestParam Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        Patient p = new Patient();
        p.setName(name);
        p.setEmail(email);
        p.setPhone(phone);
        p.setDateOfBirth(LocalDate.parse(dateOfBirth));
        p.setAddress(address);
        p.setBloodGroup(bloodGroup);
        p.setMedicalHistory(medicalHistory);
        p.setUser(user);
        patientRepository.save(p);
        return "redirect:/admin/patients";
    }
}
