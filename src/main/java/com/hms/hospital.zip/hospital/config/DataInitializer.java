package com.hms.hospital.config;

import com.hms.hospital.entity.*;
import com.hms.hospital.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Configuration
public class DataInitializer {

    @Bean
    public CommandLineRunner initData(UserRepository userRepo, DepartmentRepository deptRepo, 
                                     DoctorRepository doctorRepo, PatientRepository patientRepo,
                                     AppointmentRepository appointmentRepo, PrescriptionRepository prescriptionRepo,
                                     ReportRepository reportRepo, PasswordEncoder passwordEncoder) {
        return args -> {
            // Create departments
            Department cardiology = new Department(null, "Cardiology", "Heart and cardiovascular diseases", "555-0101");
            Department orthopedics = new Department(null, "Orthopedics", "Bones and joints", "555-0102");
            Department neurology = new Department(null, "Neurology", "Brain and nervous system", "555-0103");
            
            deptRepo.save(cardiology);
            deptRepo.save(orthopedics);
            deptRepo.save(neurology);

            // Create doctors
            Doctor doc1 = new Doctor(null, "Dr. John Smith", "Cardiologist", "john@hospital.com", "555-1001", cardiology, "MD", 10);
            Doctor doc2 = new Doctor(null, "Dr. Sarah Johnson", "Orthopedic Surgeon", "sarah@hospital.com", "555-1002", orthopedics, "MD", 8);
            Doctor doc3 = new Doctor(null, "Dr. Michael Brown", "Neurologist", "michael@hospital.com", "555-1003", neurology, "MD", 12);
            
            doctorRepo.save(doc1);
            doctorRepo.save(doc2);
            doctorRepo.save(doc3);

            // Create users
            User adminUser = new User(null, "admin", passwordEncoder.encode("admin123"), "admin@hospital.com", "ADMIN", true);
            User regularUser = new User(null, "user", passwordEncoder.encode("user123"), "user@hospital.com", "USER", true);
            User doctorUser = new User(null, "doctor", passwordEncoder.encode("doctor123"), "doctor@hospital.com", "DOCTOR", true);
            
            userRepo.save(adminUser);
            userRepo.save(regularUser);
            userRepo.save(doctorUser);

            // Create patients
            Patient patient1 = new Patient(null, "John Doe", "john@example.com", "555-2001", LocalDate.of(1990, 5, 15), "123 Main St", "O+", "None", regularUser);
            Patient patient2 = new Patient(null, "Jane Smith", "jane@example.com", "555-2002", LocalDate.of(1985, 8, 22), "456 Oak Ave", "A+", "Diabetes", regularUser);
            
            patientRepo.save(patient1);
            patientRepo.save(patient2);

            // Create appointments
            Appointment apt1 = new Appointment(null, patient1, doc1, cardiology, LocalDateTime.now().plusDays(5), "Regular checkup", "SCHEDULED", null);
            Appointment apt2 = new Appointment(null, patient2, doc2, orthopedics, LocalDateTime.now().plusDays(3), "Knee pain consultation", "SCHEDULED", null);
            
            appointmentRepo.save(apt1);
            appointmentRepo.save(apt2);

            // Create prescriptions
            Prescription pres1 = new Prescription(null, patient1, doc1, "Aspirin", "500mg", "Once daily", "30 days", LocalDate.now(), "Take with water");
            Prescription pres2 = new Prescription(null, patient1, doc1, "Atorvastatin", "20mg", "Once daily at night", "90 days", LocalDate.now(), "Do not skip doses");
            Prescription pres3 = new Prescription(null, patient2, doc2, "Ibuprofen", "200mg", "Three times daily", "7 days", LocalDate.now().minusDays(5), "Take with food");
            
            prescriptionRepo.save(pres1);
            prescriptionRepo.save(pres2);
            prescriptionRepo.save(pres3);

            // Create reports
            Report rep1 = new Report(null, "Monthly Patient Statistics", "This month we had 45 new patient registrations. The Cardiology department handled 15 cases, Orthopedics handled 20 cases, and Neurology handled 10 cases.", LocalDate.now());
            Report rep2 = new Report(null, "Appointment Performance", "Total appointments scheduled: 120. Completed: 110. Pending: 10. Cancellation rate: 2.5%", LocalDate.now().minusDays(5));
            Report rep3 = new Report(null, "Doctor Efficiency Report", "Average patient satisfaction: 4.7/5. Most consultations completed within 30 minutes.", LocalDate.now().minusDays(10));
            
            reportRepo.save(rep1);
            reportRepo.save(rep2);
            reportRepo.save(rep3);
        };
    }
}
